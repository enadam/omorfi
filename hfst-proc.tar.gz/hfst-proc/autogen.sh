#!/bin/sh

autoreconf -i
./configure $1
